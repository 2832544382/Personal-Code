import gmaths.*;

import com.jogamp.opengl.*;

import java.util.Arrays;
import java.util.List;

public class Scene_GLEventListener implements GLEventListener {
  
  private static final boolean DISPLAY_SHADERS = false;
    
  public Scene_GLEventListener(Camera camera) {
    this.camera = camera;
    this.camera.setPosition(new Vec3(0f,20f,24f));
  }
  
  // ***************************************************
  /*
   * METHODS DEFINED BY GLEventListener
   */

  /* Initialisation */
  public void init(GLAutoDrawable drawable) {   
    GL3 gl = drawable.getGL().getGL3();
    System.err.println("Chosen GLCapabilities: " + drawable.getChosenGLCapabilities());
    gl.glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    gl.glClearDepth(1.0f);
    gl.glEnable(GL.GL_DEPTH_TEST);
    gl.glDepthFunc(GL.GL_LESS);
    gl.glFrontFace(GL.GL_CCW);    // default is 'CCW'
    gl.glEnable(GL.GL_CULL_FACE); // default is 'not enabled'
    gl.glCullFace(GL.GL_BACK);   // default is 'back', assuming CCW
    initialise(gl);
    startTime = getSeconds();
  }
  
  /* Called to indicate the drawing surface has been moved and/or resized  */
  public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height) {
    GL3 gl = drawable.getGL().getGL3();
    gl.glViewport(x, y, width, height);
    float aspect = (float)width/(float)height;
    camera.setPerspectiveMatrix(Mat4Transform.perspective(45, aspect));
  }

  /* Draw */
  public void display(GLAutoDrawable drawable) {
    GL3 gl = drawable.getGL().getGL3();
    render(gl);
  }

  /* Clean up memory, if necessary */
  public void dispose(GLAutoDrawable drawable) {
    GL3 gl = drawable.getGL().getGL3();
    lampleft.dispose(gl);
    lampright.dispose(gl);
    table.dispose(gl);


    for (Light l : lightt){
      l.dispose(gl);
    }
    for (Light l : spotLights){
      l.dispose(gl);
    }



    /*
    lights.dispose(gl);
    light1.dispose(gl);
    light2.dispose(gl);
    lampLight.dispose(gl);

     */



  }
  
  // ***************************************************
  /* INTERACTION
   *
   *
   */

  /*
   set booleans to control lamps' poses
   */

  private boolean pose1L = false;
  private boolean pose2L = false;
  private boolean pose3L = false;
  private boolean pose1R = false;
  private boolean pose2R = false;
  private boolean pose3R = false;
  private boolean switchLightOn = true;
  private boolean switchLightOff = true;
  private double savedTime = 0;

  public void stopPose1L() {
    pose1L = false;
  }
  public void stopPose2L() {
    pose2L = false;
  }
  public void stopPose3L() {
    pose3L = false;
  }
  public void stopPose1R() {
    pose1R = false;
  }
  public void stopPose2R() {
    pose2R = false;
  }
  public void stopPose3R() {
    pose3R = false;
  }

  /*
  set lamps' poses
   */

  public void leftPose1() {
    pose1L = true;
    startTime = getSeconds() - savedTime;
  }

  public void leftPose2() {
    pose2L = true;
    startTime = getSeconds() - savedTime;
  }

  public void leftPose3() {
    pose3L = true;
    startTime = getSeconds() - savedTime;
  }

  public void rightPose1() {
    pose1R = true;
    startTime = getSeconds() - savedTime;
  }

  public void rightPose2() {
    pose2R = true;
    startTime = getSeconds() - savedTime;
  }

  public void rightPose3() {
    pose3R = true;
    startTime = getSeconds() - savedTime;
  }

  /*
   Change light with buttons
   */

  public void turnOn1() {
    if (switchLightOn){
      lightt.get(0).setLight(1f);
    }
  }
  public void turnOff1() {
    if (switchLightOff){
      lightt.get(0).setLight(0.4f);
    }
  }
  public void turnOn2() {
    if (switchLightOn){
      lightt.get(1).setLight(1f);
    }
  }
  public void turnOff2() {
    if (switchLightOff){
      lightt.get(1).setLight(0.4f);
    }
  }
  public void turnOn3() {
    if (switchLightOn){
      spotLights.get(0).setLight(1f);
    }
  }
  public void turnOff3() {
    if (switchLightOff){
      spotLights.get(0).setLight(0.4f);
    }
  }
  public void turnOn4() {
    if (switchLightOn){
      spotLights.get(1).setLight(1f);
    }
  }
  public void turnOff4() {
    if (switchLightOff){
      spotLights.get(1).setLight(0.4f);
    }
  }
  
  // Scene

  private Camera camera;
  private Model floor,wall,cloud,glass;
  List<Light> lightt, spotLights;
  private Light lampSpotLight1, lampSpotLight2;
  private Light lights, spotLight, light1, light2, lampLight;

  private LampLeft lampleft;
  private LampRight lampright;
  private Table table;

  private void initialise(GL3 gl) {
    createRandomNumbers();

    /*
    All textures
    */
    int[] textureId0 = TextureLibrary.loadTexture(gl, "textures/wood_floor.jpg");
    int[] textureID1 = TextureLibrary.loadTexture(gl,"textures/wall.jpg");
    int[] textureID2 = TextureLibrary.loadTexture(gl,"textures/cloud.jpg");
    int[] textureID3 = TextureLibrary.loadTexture(gl,"textures/glass.jpg");
    int[] textureID4 = TextureLibrary.loadTexture(gl,"textures/foot.jpg");
    int[] textureID5 = TextureLibrary.loadTexture(gl,"textures/fur.jpg");
    int[] textureID6 = TextureLibrary.loadTexture(gl,"textures/tail.jpg");
    int[] textureID7 = TextureLibrary.loadTexture(gl,"textures/joint.jpg");
    int[] textureID8 = TextureLibrary.loadTexture(gl,"textures/head.jpg");
    int[] textureID9 = TextureLibrary.loadTexture(gl,"textures/corn.jpg");
    int[] textureID10 = TextureLibrary.loadTexture(gl,"textures/eye.jpg");
    int[] textureID11 = TextureLibrary.loadTexture(gl,"textures/jade.jpg");
    int[] textureID12 = TextureLibrary.loadTexture(gl,"textures/jade_specular.jpg");
    int[] textureID13 = TextureLibrary.loadTexture(gl,"textures/table.jpg");
    int[] textureID14 = TextureLibrary.loadTexture(gl,"textures/box.jpg");
    int[] textureID15 = TextureLibrary.loadTexture(gl, "textures/dotFur.jpg");

    /*
    Define all lights and use Arrays.asList() to store elements
     */
    Light light1 = new Light(gl, camera);
    light1.setCamera(camera);
    light1.setPosition(getLightRightPosition());
    Light light2= new Light(gl, camera);
    light2.setCamera(camera);
    light2.setPosition(getLightLeftPosition());
    lampSpotLight1 = new spotLight(gl, camera);
    lampSpotLight1.setCamera(camera);
    lampSpotLight2 = new spotLight(gl, camera);
    lampSpotLight2.setCamera(camera);
    lightt = Arrays.asList(light1, light2);
    spotLights = Arrays.asList(lampSpotLight1, lampSpotLight2);

    /*
    Define all objects
     */

    Mesh meshFloor = new Mesh(gl, TwoTriangles.vertices.clone(), TwoTriangles.indices.clone());
    Shader shaderFloor = new Shader(gl, "vs_tt.txt", "fs_tt.txt");
    Material materialFloor = new Material(new Vec3(0.1f, 0.5f, 0.91f), new Vec3(0.1f, 0.5f, 0.91f), new Vec3(0.3f, 0.3f, 0.3f), 32.0f);
    Mat4 modelMatrixFloor = Mat4Transform.scale(16,1f,16);
    floor = new Model(gl, camera, lightt,  spotLights,shaderFloor, materialFloor, modelMatrixFloor, meshFloor, textureId0);

    Mesh meshWall = new Mesh(gl, TwoTriangles.vertices.clone(),TwoTriangles.indices.clone());
    Shader shaderWall = new Shader(gl, "vs_tt.txt", "fs_tt.txt");
    Material materialWall = new Material(new Vec3(0.1f, 0.5f, 0.91f), new Vec3(0.1f, 0.5f, 0.91f), new Vec3(0.3f, 0.3f, 0.3f), 4.0f);
    Mat4 modelMatrixWall = Mat4Transform.scale(16,1f,16);
    wall = new Model(gl, camera, lightt, spotLights,shaderWall, materialWall, modelMatrixWall, meshWall, textureID1);

    Mesh meshGlass = new Mesh(gl, TwoTriangles.vertices.clone(),TwoTriangles.indices.clone());
    Shader shaderGlass = new Shader(gl, "vs_glass.txt", "fs_glass.txt");
    Material materialGlass = new Material(new Vec3(1.0f, 1.0f, 1.0f), new Vec3(1.0f, 1.0f, 1.0f), new Vec3(0.7f, 0.7f, 0.7f), 16.0f);
    Mat4 modelMatrixGlass = Mat4Transform.scale(16,1f,16);
    glass = new Model(gl, camera, lightt, spotLights,shaderGlass, materialGlass, modelMatrixGlass, meshGlass,textureID3,textureID2);

    Mesh meshCloud = new Mesh(gl, TwoTriangles.vertices.clone(),TwoTriangles.indices.clone());
    Shader shaderCloud = new Shader(gl, "vs_cloud.txt", "fs_cloud.txt");
    Material materialCloud = new Material(new Vec3(0.0f, 0.5f, 0.81f), new Vec3(0.0f, 0.5f, 0.81f), new Vec3(0.3f, 0.3f, 0.3f), 32.0f);
    Mat4 modelMatrixCloud = Mat4Transform.scale(32,1f,32);
    cloud = new Model(gl, camera, lightt, spotLights,shaderCloud, materialCloud, modelMatrixCloud, meshCloud, textureID2);

    lampleft = new LampLeft(gl, camera, lightt, spotLights, textureID4,textureID5,textureID6,textureID7,textureID8,textureID9,textureID10);

    lampright = new LampRight(gl, camera, lightt, spotLights, textureID15,textureID10);

    table = new Table(gl,camera,lightt, spotLights,textureID11,textureID12,textureID13,textureID14);
  }

  // Render all objects
  private void render(GL3 gl) {
    gl.glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);


    for (Light l: lightt){
      l.render(gl);
    }

    floor.render(gl);

    double elapsedTime = getSeconds()-startTime;
    table.rotate_and_jump(elapsedTime);

    /*
    add booleans to control the moves
     */
    if (pose1L){
      if(elapsedTime <= 1.2) {
        lampleft.firstPoseL(elapsedTime);
      }
      else{
        stopPose1L();
        lampleft.setPose1Left();
      }
    }
    else if (pose2L){
      if (elapsedTime <= 1.2) {
        lampleft.secondPoseL(elapsedTime);
      }
      else{
        stopPose2L();
        lampleft.setPose2Left();
      }
    }
    else if (pose3L){
      if (elapsedTime <= 1.2) {
        lampleft.thirdPoseL(elapsedTime);
      }
      else{
        stopPose3L();
        lampleft.setPose3Left();
      }
    }
    else if (pose1R){
      if(elapsedTime <= 1.2) {
        lampright.firstPoseR(elapsedTime);
      }
      else{
        stopPose1R();
        lampright.setPose1Right();
      }
    }
    else if (pose2R){
      if (elapsedTime <= 1.2) {
        lampright.secondPoseR(elapsedTime);
      }
      else{
        stopPose2R();
        lampright.setPose2Right();
      }
    }
    else if (pose3R){
      if (elapsedTime <= 1.2) {
        lampright.thirdPoseR(elapsedTime);
      }
      else{
        stopPose3R();
        lampright.setPose3Right();
      }
    }

    floor.setModelMatrix(getMforFloor());
    floor.render(gl);
    wall.setModelMatrix(getMforWallL());
    wall.render(gl);
    wall.setModelMatrix(getMforWallR());
    wall.render(gl);
    glass.setModelMatrix(getMforGlass());
    glass.render(gl);
    cloud.setModelMatrix(getMforCloud());
    cloud.render(gl);
    lampleft.render(gl);
    lampright.render(gl);
    table.render(gl);
  }
  
  // The light's position
  private Vec3 getLightLeftPosition() {
    float x = 5.0f;
    float y = 5.0f;
    float z = -4f;
    return new Vec3(x,y,z);
  }

  private Vec3 getLightRightPosition() {
    float x = -5.0f;
    float y = 5.0f;
    float z = -4f;
    return new Vec3(x,y,z);
  }

  // objects' position
  private Mat4 getMforFloor() {
    float size = 16f;
    Mat4 modelMatrix = new Mat4(1);
    modelMatrix = Mat4.multiply(Mat4Transform.scale(size,1f,size), modelMatrix);
    return modelMatrix;
  }
  private Mat4 getMforWallL() {

    float size = 16f;
    Mat4 modelMatrix = new Mat4(1);
    modelMatrix = Mat4.multiply(Mat4Transform.scale(size,1f,size), modelMatrix);
    modelMatrix = Mat4.multiply(Mat4Transform.rotateAroundY(90), modelMatrix);
    modelMatrix = Mat4.multiply(Mat4Transform.rotateAroundZ(-90), modelMatrix);
    modelMatrix = Mat4.multiply(Mat4Transform.translate(-size*0.5f,size*0.5f,0), modelMatrix);
    return modelMatrix;
  }

  private Mat4 getMforWallR() {

    float size = 16f;
    Mat4 modelMatrix = new Mat4(1);
    modelMatrix = Mat4.multiply(Mat4Transform.scale(size,1f,size), modelMatrix);
    modelMatrix = Mat4.multiply(Mat4Transform.rotateAroundX(90), modelMatrix);
    modelMatrix = Mat4.multiply(Mat4Transform.rotateAroundY(-90), modelMatrix);
    modelMatrix = Mat4.multiply(Mat4Transform.translate(size/2,0f,size/2), modelMatrix);

    modelMatrix = Mat4.multiply(Mat4Transform.translate(0,size*0.5f,-size*0.5f), modelMatrix);
    return modelMatrix;
  }

  private Mat4 getMforGlass() {

    float size = 16f;
    Mat4 modelMatrix = new Mat4(1);
    modelMatrix = Mat4.multiply(Mat4Transform.scale(size,1f,size), modelMatrix);
    modelMatrix = Mat4.multiply(Mat4Transform.rotateAroundX(90), modelMatrix);

    modelMatrix = Mat4.multiply(Mat4Transform.translate(0,size*0.5f,-size*0.5f), modelMatrix);
    return modelMatrix;
  }

  private Mat4 getMforCloud() {
    float size = 32f;
    float distanceX = 0f;
    float distanceY = 4f;
    float distanceZ = -26f;
    Mat4 modelMatrix = new Mat4(1);
    modelMatrix = Mat4.multiply(Mat4Transform.scale(size,1f,size), modelMatrix);
    modelMatrix = Mat4.multiply(Mat4Transform.rotateAroundX(90), modelMatrix);
    modelMatrix = Mat4.multiply(Mat4Transform.translate(distanceX,distanceY,distanceZ), modelMatrix);

    return modelMatrix;
  }

  /* TIME
   */ 
  
  private double startTime;
  
  private double getSeconds() {
    return System.currentTimeMillis()/1000.0;
  }

  /* An array of random numbers
   */
  private int NUM_RANDOMS = 1000;
  private float[] randoms;
  
  private void createRandomNumbers() {
    randoms = new float[NUM_RANDOMS];
    for (int i=0; i<NUM_RANDOMS; ++i) {
      randoms[i] = (float)Math.random();
    }
  }


}