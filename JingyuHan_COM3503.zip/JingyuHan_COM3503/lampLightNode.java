import com.jogamp.opengl.GL3;

public class lampLightNode extends SGNode {
    /*
    Add a function to allow model can add light
    */

    private Light light;
    public lampLightNode(String name, Light lampLight){
        super(name);
        light = lampLight;
    }

    public void draw(GL3 gl){
        light.render(gl, worldTransform);

    }

}
