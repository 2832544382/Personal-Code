import gmaths.*;

import java.nio.*;
import java.util.ArrayList;
import java.util.List;

import com.jogamp.common.nio.*;
import com.jogamp.opengl.*;
import com.jogamp.opengl.util.*;
import com.jogamp.opengl.util.awt.*;
import com.jogamp.opengl.util.glsl.*;

public class Table {

    private Model sphere, cubeTable, cubeBox;

    private SGNode tableRoot;
    private float xPosition = 0;
    private TransformNode  tableMoveTranslate, ballRotate, ballTranslate;


    public Table(GL3 gl, Camera camera,  List<Light> light, List<Light> spotLights, int[] textureId11, int[] textureId12, int[] textureId13, int[] textureId14) {

        //table objects
        Mesh mesh = new Mesh(gl, Sphere.vertices.clone(), Sphere.indices.clone());
        Shader shader = new Shader(gl, "vs_cube.txt", "fs_cube.txt");
        Material material = new Material(new Vec3(1.0f, 0.5f, 0.31f), new Vec3(1.0f, 0.5f, 0.31f), new Vec3(0.5f, 0.5f, 0.5f), 32.0f);
        Mat4 modelMatrix = Mat4.multiply(Mat4Transform.scale(4,4,4), Mat4Transform.translate(0,0.5f,0));
        sphere = new Model(gl, camera, light, spotLights,shader, material, modelMatrix, mesh, textureId11, textureId12);

        mesh = new Mesh(gl, Cube.vertices.clone(), Cube.indices.clone());
        shader = new Shader(gl, "vs_cube.txt", "fs_cube.txt");
        material = new Material(new Vec3(1.0f, 0.5f, 0.31f), new Vec3(1.0f, 0.5f, 0.31f), new Vec3(0.5f, 0.5f, 0.5f), 32.0f);
        modelMatrix = Mat4.multiply(Mat4Transform.scale(4,4,4), Mat4Transform.translate(0,0.5f,0));
        cubeTable = new Model(gl, camera, light, spotLights,shader, material, modelMatrix, mesh, textureId13);

        cubeBox = new Model(gl, camera, light, spotLights,shader, material, modelMatrix, mesh, textureId14);


        //table's data
        float tableLegHeight = 2f;
        float tableLegWidth = 0.5f;
        float tableLegLength = 0.5f;
        float tableHeight = 0.3f;
        float tableLength = 3.5f;
        float tableWidth = 3.5f;
        float boxLength = 1.2f;
        float boxHeight = 0.4f;
        float boxWidth = 0.8f;
        float sphereScale = 1.5f;
        float sphereHeightScale = 2.3f;

        // Define node to build branch
        tableRoot = new NameNode("table root");
        tableMoveTranslate = new TransformNode("table transform",Mat4Transform.translate(xPosition,0,0));

        NameNode leg1 = new NameNode("leg 1");
        TransformNode leg1Translate = new TransformNode("leg1 translate", Mat4Transform.translate(0.5f * (-tableLength + tableLegLength),0,0.5f * (-tableWidth + tableLegWidth)));
        Mat4 m = Mat4Transform.scale(tableLegLength,tableLegHeight,tableLegWidth);
        m = Mat4.multiply(m, Mat4Transform.translate(0,0.5f,0));
        TransformNode leg1Transform = new TransformNode("leg 1 transform", m);
        ModelNode leg1Shape = new ModelNode("CubeTable(leg1)", cubeTable);

        NameNode leg2 = new NameNode("leg 2");
        TransformNode leg2Translate = new TransformNode("leg2 translate", Mat4Transform.translate(0.5f * (tableLength - tableLegLength),0,0.5f * (-tableWidth + tableLegWidth)));
        m = new Mat4(1);
        m = Mat4.multiply(m, Mat4Transform.scale(tableLegLength,tableLegHeight,tableLegWidth));
        m = Mat4.multiply(m, Mat4Transform.translate(0,0.5f,0));
        TransformNode leg2Transform = new TransformNode("leg 2 transform", m);
        ModelNode leg2Shape = new ModelNode("CubeTable(leg2)", cubeTable);

        NameNode leg3 = new NameNode("leg 3");
        TransformNode leg3Translate = new TransformNode("leg3 translate", Mat4Transform.translate(0.5f * (-tableLength + tableLegLength),0,0.5f * (tableWidth - tableLegWidth)));
        m = new Mat4(1);
        m = Mat4.multiply(m, Mat4Transform.scale(tableLegLength,tableLegHeight,tableLegWidth));
        m = Mat4.multiply(m, Mat4Transform.translate(0,0.5f,0));
        TransformNode leg3Transform = new TransformNode("leg 3 transform", m);
        ModelNode leg3Shape = new ModelNode("CubeTable(leg3)", cubeTable);

        NameNode leg4 = new NameNode("leg 4");
        TransformNode leg4Translate = new TransformNode("leg4 translate", Mat4Transform.translate(0.5f * (tableLength - tableLegLength),0,0.5f * (tableWidth - tableLegWidth)));
        m = new Mat4(1);
        m = Mat4.multiply(m, Mat4Transform.scale(tableLegLength,tableLegHeight,tableLegWidth));
        m = Mat4.multiply(m, Mat4Transform.translate(0,0.5f,0));
        TransformNode leg4Transform = new TransformNode("leg 4 transform", m);
        ModelNode leg4Shape = new ModelNode("CubeTable(leg4)", cubeTable);

        NameNode tableSurface = new NameNode("table surface");
        m = new Mat4(1);
        m = Mat4.multiply(m, Mat4Transform.translate(0,tableLegHeight,0));
        m = Mat4.multiply(m, Mat4Transform.scale(tableLength,tableHeight,tableWidth));
        m = Mat4.multiply(m, Mat4Transform.translate(0,0.5f,0));
        TransformNode tableSurfaceTransform = new TransformNode("table surface transform", m);
        ModelNode tableSurfaceShape = new ModelNode("CubeTable(surface)", cubeTable);

        NameNode boxOnTable = new NameNode("box");
        m = new Mat4(1);
        m = Mat4.multiply(m, Mat4Transform.translate(0,tableLegHeight + tableHeight,0));
        m = Mat4.multiply(m, Mat4Transform.scale(boxLength,boxHeight,boxWidth));
        m = Mat4.multiply(m, Mat4Transform.translate(0,0.5f,0));
        TransformNode boxTransform = new TransformNode("box transform", m);
        ModelNode boxShape = new ModelNode("CubeBox(box)", cubeTable);

        NameNode sphereOnBox = new NameNode("sphere");
        ballTranslate = new TransformNode("ball translate", Mat4Transform.translate(0,tableLegHeight + tableHeight + boxHeight,0));
        ballRotate =new TransformNode("ball rotate", Mat4Transform.rotateAroundY(0));
        m = new Mat4(1);
        m = Mat4.multiply(m, Mat4Transform.scale(sphereScale,sphereHeightScale,sphereScale));
        m = Mat4.multiply(m, Mat4Transform.translate(0,0.5f,0));
        TransformNode sphereTransform = new TransformNode("sphere transform", m);
        ModelNode sphereShape = new ModelNode("sphere(sphere)", sphere);

        //build branch
        tableRoot.addChild(tableMoveTranslate);
            tableMoveTranslate.addChild(leg1);
                leg1.addChild(leg1Translate);
                leg1Translate.addChild(leg1Transform);
                leg1Transform.addChild(leg1Shape);
            tableMoveTranslate.addChild(leg2);
                leg2.addChild(leg2Translate);
                leg2Translate.addChild(leg2Transform);
                leg2Transform.addChild(leg2Shape);
            tableMoveTranslate.addChild(leg3);
                leg3.addChild(leg3Translate);
                leg3Translate.addChild(leg3Transform);
                leg3Transform.addChild(leg3Shape);
            tableMoveTranslate.addChild(leg4);
                leg4.addChild(leg4Translate);
                leg4Translate.addChild(leg4Transform);
                leg4Transform.addChild(leg4Shape);
            tableMoveTranslate.addChild(tableSurface);
                tableSurface.addChild(tableSurfaceTransform);
                tableSurfaceTransform.addChild(tableSurfaceShape);
            tableMoveTranslate.addChild(boxOnTable);
                boxOnTable.addChild(boxTransform);
                boxTransform.addChild(boxShape);
            tableMoveTranslate.addChild(boxOnTable);
                boxOnTable.addChild(boxTransform);
                boxTransform.addChild(boxShape);
            tableMoveTranslate.addChild(sphereOnBox);
                sphereOnBox.addChild(ballTranslate);
                    ballTranslate.addChild(ballRotate);
                    ballRotate.addChild(sphereTransform);
                    sphereTransform.addChild(sphereShape);

        tableRoot.update();  // IMPORTANT - don't forget this
    }

    public void render(GL3 gl) {
        tableRoot.draw(gl);
    }

    //A function makes egg move
    public void rotate_and_jump(double elapsedTime){
        float rotateAngle = (float)(elapsedTime*100);
        float sphereHeight = 1f;
        float upAndDown =(float)Math.sin(elapsedTime*1.2) + sphereHeight;
        ballRotate.setTransform(Mat4.multiply((Mat4Transform.rotateAroundY(rotateAngle)),Mat4Transform.translate(0,upAndDown,0)));
        ballRotate.update();
    }

    public void dispose(GL3 gl) {
        sphere.dispose(gl);
        cubeTable.dispose(gl);
        cubeBox.dispose(gl);
    }
}