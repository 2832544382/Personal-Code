Scene_EventLisntener()
I tried to make all buttons work, but a few buttons about light could not work, so I left the buttons that could work and others in the program to show my thinking.