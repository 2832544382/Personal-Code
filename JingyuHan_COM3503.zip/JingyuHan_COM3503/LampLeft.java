import gmaths.*;

import com.jogamp.opengl.*;

import java.util.ArrayList;
import java.util.List;

/**
 * This class stores the Robot
 *
 * @author    Dr Steve Maddock
 * @version   1.0 (31/08/2022)
 */

public class LampLeft {
    private Model arm, ball, joint, tail, head, corn, foot;
    private Light lightLeftLamp;
    private SGNode lampRootLeft;
    private float xPosition = 0;
    private TransformNode lampMoveTranslate, armLowerRotate, armUpperRotate, headRotate;

    public LampLeft(GL3 gl, Camera camera,  List<Light> light, List<Light> spotLights, int[] textureID4, int[] textureID5, int[] textureID6,
                    int[] textureID7, int[] textureID8, int[] textureID9, int[] textureID10) {

        this.lightLeftLamp = spotLights.get(0);

        Mesh mesh = new Mesh(gl, Sphere.vertices.clone(), Sphere.indices.clone());
        Shader shader = new Shader(gl, "vs_cube.txt", "fs_cube.txt");
        Material material = new Material(new Vec3(1.0f, 0.5f, 0.31f), new Vec3(1.0f, 0.5f, 0.31f), new Vec3(0.5f, 0.5f, 0.5f), 32.0f);
        Mat4 modelMatrix = Mat4Transform.translate(0,0.5f,0);
        arm = new Model(gl, camera, light, spotLights,shader, material, modelMatrix, mesh, textureID5);

        ball = new Model(gl, camera, light, spotLights,shader, material, modelMatrix, mesh, textureID10);

        joint = new Model(gl, camera, light, spotLights,shader, material, modelMatrix, mesh, textureID7);

        mesh = new Mesh(gl, Cube.vertices.clone(), Cube.indices.clone());
        shader = new Shader(gl, "vs_cube.txt", "fs_cube.txt");
        material = new Material(new Vec3(1.0f, 0.5f, 0.31f), new Vec3(1.0f, 0.5f, 0.31f), new Vec3(0.5f, 0.5f, 0.5f), 32.0f);
        modelMatrix = Mat4Transform.translate(0,0.5f,0);
        head = new Model(gl, camera, light, spotLights,shader, material, modelMatrix, mesh, textureID8);

        tail = new Model(gl, camera, light, spotLights,shader, material, modelMatrix, mesh, textureID6);

        corn = new Model(gl, camera, light, spotLights,shader, material, modelMatrix, mesh, textureID9);

        foot = new Model(gl, camera, light, spotLights,shader, material, modelMatrix, mesh, textureID4);

        // lamp data
        float armUpperHeight = 2f;
        float armUpperScale = 0.4f;
        float armLowerHeight = 1.7f;
        float armLowerScale = 0.38f;
        float jointScale = 0.4f;
        float ballsScale = 0.4f;
        float headHeight = 0.8f;
        float headWidth = 0.8f;
        float headLength = 0.8f;
        float tailHeight = 0.15f;
        float tailWidth = 0.15f;
        float tailLength = 1.6f;
        float earHeight = 0.15f;
        float earWidth = 0.15f;
        float earLength = 0.25f;
        float footHeight = 0.1f;
        float footWidth = 0.8f;
        float footLength = 0.8f;
        float lightSize = 0.3f;
        float left = -4f;

        //lamp branches
        lampRootLeft = new NameNode("lampLeft root");
        lampMoveTranslate = new TransformNode("lampLeft transform",Mat4Transform.translate(xPosition,0,0));

        TransformNode lampTranslate = new TransformNode("lampLeft transform",Mat4Transform.translate(0,footHeight,0));
        NameNode lampFoot = new NameNode("foot");
        TransformNode footTranslate = new TransformNode("lower arm translate", Mat4Transform.translate(left,0,0));
        Mat4 m = Mat4Transform.scale(footLength,footHeight,footWidth);
        m = Mat4.multiply(m, Mat4Transform.translate(0,0.5f,0));
        TransformNode footTransform = new TransformNode("foot transform", m);
        ModelNode footShape = new ModelNode("foot(foot)", foot);

        NameNode armLower = new NameNode("arm lower");
        TransformNode armLowerTranslate = new TransformNode("lower arm translate", Mat4Transform.translate(left,footHeight,0));
        armLowerRotate = new TransformNode("lower arm rotate", Mat4Transform.rotateAroundZ(0));

        m = new Mat4(1);
        m = Mat4.multiply(m, Mat4Transform.scale(armLowerScale,armLowerHeight,armLowerScale));
        m = Mat4.multiply(m, Mat4Transform.translate(0,0.5f,0));
        TransformNode lowerArmScale = new TransformNode("arm lower transform", m);
        ModelNode armLowerShape = new ModelNode("arm(lower)", arm);

        NameNode armUpper = new NameNode("arm upper");
        TransformNode armUpperTranslate = new TransformNode("upper arm translate", Mat4Transform.translate(0,footHeight + armLowerHeight + jointScale - 0.1f,0));
        armUpperRotate = new TransformNode("upper arm rotate", Mat4Transform.rotateAroundX(0));
        m = new Mat4(1);
        m = Mat4.multiply(m, Mat4Transform.scale(armUpperScale,armUpperHeight,armUpperScale));
        m = Mat4.multiply(m, Mat4Transform.translate(0,0.5f,0));
        TransformNode upperArmScale = new TransformNode("arm lower transform", m);
        ModelNode armUpperShape = new ModelNode("arm(upper)", arm);

        NameNode armJoint = new NameNode("joint");
        m = new Mat4(1);
        m = Mat4.multiply(m, Mat4Transform.translate(0,footHeight + armLowerHeight-0.1f,0));
        m = Mat4.multiply(m, Mat4Transform.scale(jointScale,jointScale,jointScale));
        m = Mat4.multiply(m, Mat4Transform.translate(0,0.5f,0));
        TransformNode armJointTransform = new TransformNode("joint transform", m);
        ModelNode armJointShape = new ModelNode("joint(joint)", joint);

        NameNode jointTail = new NameNode("tail");
        TransformNode tailTranslate = new TransformNode("joint translate", Mat4Transform.translate(-jointScale - (jointScale * 0.5f),footHeight+armLowerHeight+(jointScale*0.5f)+0.2f,0));
        m = new Mat4(1);
        m = Mat4.multiply(m, (Mat4Transform.rotateAroundZ(-30)));
        m = Mat4.multiply(m, Mat4Transform.scale(tailLength, tailHeight, tailWidth));
        m = Mat4.multiply(m, Mat4Transform.translate(0,0.5f,0));
        TransformNode jointTailScale = new TransformNode("joint tail transform", m);
        ModelNode jointTailShape = new ModelNode("joint(tail)", tail);

        NameNode headMain = new NameNode("headMain");
        TransformNode headTranslate = new TransformNode("head main translate", Mat4Transform.translate(0,armUpperHeight-0.2f,0));
        headRotate = new TransformNode("head rotate", Mat4Transform.rotateAroundX(0));
        m = new Mat4(1);
        m = Mat4.multiply(m, Mat4Transform.scale(headLength,headHeight,headWidth));
        m = Mat4.multiply(m, Mat4Transform.translate(0,0.5f,0));
        TransformNode headMainScale = new TransformNode("head main transform", m);
        ModelNode headMainShape = new ModelNode("head(main)", head);

        NameNode headCorn1 = new NameNode("corn1");
        TransformNode corn1Translate = new TransformNode("corn1 translate", Mat4Transform.translate((0.5f * -headLength),headHeight,-0.5f*(headWidth - earWidth)));
        m = new Mat4(1);
        m = Mat4.multiply(m, Mat4.multiply(Mat4Transform.rotateAroundX(-25),Mat4Transform.rotateAroundZ(-45)));
        m = Mat4.multiply(m, Mat4Transform.scale(earLength,earHeight,earWidth));
        m = Mat4.multiply(m, Mat4Transform.translate(0,0.5f,0));
        TransformNode headCorn1Scale = new TransformNode("corn1 transform", m);
        ModelNode headCorn1Shape = new ModelNode("head(corn1)", corn);

        NameNode headCorn2 = new NameNode("corn2");
        TransformNode corn2Translate = new TransformNode("corn2 translate", Mat4Transform.translate((0.5f * -headLength),headHeight,0.5f*(headWidth - earWidth)));
        m = new Mat4(1);
        m = Mat4.multiply(m, Mat4.multiply(Mat4Transform.rotateAroundX(25),Mat4Transform.rotateAroundZ(-45)));
        m = Mat4.multiply(m, Mat4Transform.scale(earLength,earHeight,earWidth));
        m = Mat4.multiply(m, Mat4Transform.translate(0,0.5f,0));
        TransformNode headCorn2Scale = new TransformNode("corn2 transform", m);
        ModelNode headCorn2Shape = new ModelNode("head(corn2)", corn);

        NameNode headBall1 = new NameNode("ball1");
        m = new Mat4(1);
        m = Mat4.multiply(m, Mat4Transform.translate(0.5f * (headLength-ballsScale),headHeight,-0.5f*(headWidth - ballsScale)));
        m = Mat4.multiply(m, Mat4Transform.rotateAroundY(-90));
        m = Mat4.multiply(m, Mat4Transform.scale(ballsScale,ballsScale,ballsScale));
        m = Mat4.multiply(m, Mat4Transform.translate(0,0.5f,0));
        TransformNode headBall1Transform = new TransformNode("head1 transform", m);
        ModelNode headBall1Shape = new ModelNode("head(ball1)", ball);

        NameNode headBall2 = new NameNode("ball2");
        m = new Mat4(1);
        m = Mat4.multiply(m, Mat4Transform.translate(0.5f * (headLength-ballsScale),headHeight,-0.5f*(-headWidth + ballsScale)));
        m = Mat4.multiply(m, Mat4Transform.rotateAroundY(-90));
        m = Mat4.multiply(m, Mat4Transform.scale(ballsScale,ballsScale,ballsScale));
        m = Mat4.multiply(m, Mat4Transform.translate(0,0.5f,0));
        TransformNode headBall2Transform = new TransformNode("head2 transform", m);
        ModelNode headBall2Shape = new ModelNode("head(ball2)", ball);

        NameNode leftLight = new NameNode("light left lamp");
        m = new Mat4(1);
        m = Mat4.multiply(m, Mat4Transform.translate(headLength-lightSize,(headHeight*0.5f)-(lightSize*0.5f),0));
        m = Mat4.multiply(m, Mat4Transform.scale(lightSize,lightSize,lightSize));
        m = Mat4.multiply(m, Mat4Transform.translate(0,0.5f,0));
        TransformNode lightLeftTransform = new TransformNode("left light transform", m);
        lampLightNode lightLeftShape = new lampLightNode("lightLeft(left light)", lightLeftLamp);

        //build the branch
        lampRootLeft.addChild(lampMoveTranslate);
            lampMoveTranslate.addChild(lampTranslate);
                lampTranslate.addChild(lampFoot);
                    lampFoot.addChild(footTranslate);
                        footTranslate.addChild(footTransform);
                        footTransform.addChild(footShape);
                    lampFoot.addChild(armLower);
                        armLower.addChild(armLowerTranslate);
                        armLowerTranslate.addChild(armLowerRotate);
                        armLowerRotate.addChild(lowerArmScale);
                        lowerArmScale.addChild(armLowerShape);
                            armLowerRotate.addChild(armJoint);
                                armJoint.addChild(armJointTransform);
                                armJointTransform.addChild(armJointShape);
                                armLowerRotate.addChild(jointTail);
                                    jointTail.addChild(tailTranslate);
                                    tailTranslate.addChild(jointTailScale);
                                    jointTailScale.addChild(jointTailShape);
                                armJoint.addChild(armUpper);
                                    armUpper.addChild(armUpperTranslate);
                                    armUpperTranslate.addChild(armUpperRotate);
                                    armUpperRotate.addChild(upperArmScale);
                                    upperArmScale.addChild(armUpperShape);
                                    armUpperRotate.addChild(headMain);
                                        headMain.addChild(headTranslate);
                                        headTranslate.addChild(headRotate);
                                        headRotate.addChild(headMainScale);
                                        headMainScale.addChild(headMainShape);
                                        headRotate.addChild(headCorn1);
                                            headCorn1.addChild(corn1Translate);
                                            corn1Translate.addChild(headCorn1Scale);
                                            headCorn1Scale.addChild(headCorn1Shape);
                                        headRotate.addChild(headCorn2);
                                            headCorn2.addChild(corn2Translate);
                                            corn2Translate.addChild(headCorn2Scale);
                                            headCorn2Scale.addChild(headCorn2Shape);
                                        headRotate.addChild(headBall1);
                                            headBall1.addChild(headBall1Transform);
                                            headBall1Transform.addChild(headBall1Shape);
                                        headRotate.addChild(headBall2);
                                            headBall2.addChild(headBall2Transform);
                                            headBall2Transform.addChild(headBall2Shape);
                                        headRotate.addChild(leftLight);
                                            leftLight.addChild(lightLeftTransform);
                                            lightLeftTransform.addChild(lightLeftShape);


        lampFoot.update();
    }

    public void render(GL3 gl) {
        lampRootLeft.draw(gl);
        lampRootLeft.update();
    }

    //Define 3 poses
    private float lowerY1Left = -100f;
    private float lowerZ1Left = 0;
    private float upperZ1Left = -45f;
    private float headZ1Left = 50f;

    private float lowerY2Left = 130f;
    private float lowerZ2Left = 40f;
    private float upperZ2Left = -25f;
    private float headZ2Left = -10f;

    private float lowerY3Left = 0f;
    private float lowerZ3Left = 60f;
    private float upperZ3Left = -75f;
    private float headZ3Left = 35f;

    private float lyLeft = 0;
    private float lzLeft = 0;
    private float uzLeft = 0;
    private float hzLeft = 0;

    public void setPose1Left() {
        lyLeft = lowerY1Left;
        lzLeft = lowerZ1Left;
        uzLeft = upperZ1Left;
        hzLeft = headZ1Left;
    }

    public void setPose2Left() {
        lyLeft = lowerY2Left;
        lzLeft = lowerZ2Left;
        uzLeft = upperZ2Left;
        hzLeft = headZ2Left;
    }

    public void setPose3Left() {
        lyLeft = lowerY3Left;
        lzLeft = lowerZ3Left;
        uzLeft = upperZ3Left;
        hzLeft = headZ3Left;
    }

    public void firstPoseL(double elapsedTime) {
        float moveLy = ((lowerY1Left - lyLeft) * (float) (Math.sin(elapsedTime)));
        float moveLz = ((lowerZ1Left - lzLeft) * (float) (Math.sin(elapsedTime)));
        float moveUz = ((upperZ1Left - uzLeft) * (float) (Math.sin(elapsedTime)));
        float moveHz = ((headZ1Left - hzLeft) * (float) (Math.sin(elapsedTime)));

        Mat4 ly1 = Mat4.multiply(Mat4Transform.rotateAroundY(moveLy), Mat4Transform.rotateAroundY(lyLeft));
        Mat4 lz1 = Mat4.multiply(Mat4Transform.rotateAroundZ(moveLz), Mat4Transform.rotateAroundZ(lzLeft));

        armLowerRotate.setTransform(Mat4.multiply(ly1, lz1));
        armUpperRotate.setTransform(Mat4.multiply(Mat4Transform.rotateAroundZ(moveUz),
                Mat4Transform.rotateAroundZ(uzLeft)));
        headRotate.setTransform(Mat4.multiply(Mat4Transform.rotateAroundZ(moveHz),
                Mat4Transform.rotateAroundZ(hzLeft)));
    }

    public void secondPoseL(double elapsedTime) {
        float moveLy = ((lowerY2Left - lyLeft) * (float)(Math.sin(elapsedTime)));
        float moveLz = ((lowerZ2Left - lzLeft) * (float)(Math.sin(elapsedTime)));
        float moveUz = ((upperZ2Left - uzLeft) * (float)(Math.sin(elapsedTime)));
        float moveHz = ((headZ2Left - hzLeft) * (float)(Math.sin(elapsedTime)));

        Mat4 ly2 = Mat4.multiply(Mat4Transform.rotateAroundY(moveLy), Mat4Transform.rotateAroundY(lyLeft));
        Mat4 lz2 = Mat4.multiply(Mat4Transform.rotateAroundZ(moveLz), Mat4Transform.rotateAroundZ(lzLeft));

        armLowerRotate.setTransform(Mat4.multiply(ly2, lz2));
        armUpperRotate.setTransform(Mat4.multiply(Mat4Transform.rotateAroundZ(moveUz),
                Mat4Transform.rotateAroundZ(uzLeft)));
        headRotate.setTransform(Mat4.multiply(Mat4Transform.rotateAroundZ(moveHz),
                Mat4Transform.rotateAroundZ(hzLeft)));
    }

    public void thirdPoseL(double elapsedTime) {
        float moveLy = ((lowerY3Left - lyLeft) * (float)(Math.sin(elapsedTime)));
        float moveLz = ((lowerZ3Left - lzLeft) * (float)(Math.sin(elapsedTime)));
        float moveUz = ((upperZ3Left - uzLeft) * (float)(Math.sin(elapsedTime)));
        float moveHz = ((headZ3Left - hzLeft) * (float)(Math.sin(elapsedTime)));

        Mat4 ly3 = Mat4.multiply(Mat4Transform.rotateAroundY(moveLy), Mat4Transform.rotateAroundY(lyLeft));
        Mat4 lz3 = Mat4.multiply(Mat4Transform.rotateAroundZ(moveLz), Mat4Transform.rotateAroundZ(lzLeft));

        armLowerRotate.setTransform(Mat4.multiply(ly3, lz3));
        armUpperRotate.setTransform(Mat4.multiply(Mat4Transform.rotateAroundZ(moveUz),
                Mat4Transform.rotateAroundZ(uzLeft)));
        headRotate.setTransform(Mat4.multiply(Mat4Transform.rotateAroundZ(moveHz),
                Mat4Transform.rotateAroundZ(hzLeft)));
    }

    public void dispose(GL3 gl) {
        arm.dispose(gl);
        ball.dispose(gl);
        joint.dispose(gl);
        head.dispose(gl);
        tail.dispose(gl);
        corn.dispose(gl);
        foot.dispose(gl);
    }
}
