import gmaths.*;

import com.jogamp.opengl.*;

import java.util.ArrayList;
import java.util.List;

/**
 * This class stores the Robot
 *
 * @author    Dr Steve Maddock
 * @version   1.0 (31/08/2022)
 */

public class LampRight {
    private Model arm, ball, joint, tail, head, ear, foot, lampLight;
    private Light lightRightLamp;
    private SGNode lampRootRight;
    private float xPosition = 0;
    private TransformNode lampMoveTranslate, armLowerRotate, armUpperRotate, headRotate;


    public LampRight(GL3 gl, Camera camera,  List<Light> light, List<Light> spotLights, int[] textureID15, int[] textureID10) {


        this.lightRightLamp = spotLights.get(1);

        Mesh mesh = new Mesh(gl, Sphere.vertices.clone(), Sphere.indices.clone());
        Shader shader = new Shader(gl, "vs_cube.txt", "fs_cube.txt");
        Material material = new Material(new Vec3(1.0f, 0.5f, 0.31f), new Vec3(1.0f, 0.5f, 0.31f), new Vec3(0.5f, 0.5f, 0.5f), 32.0f);
        Mat4 modelMatrix = Mat4Transform.translate(0,0.5f,0);
        arm = new Model(gl, camera, light, spotLights,shader, material, modelMatrix, mesh, textureID15);

        ball = new Model(gl, camera, light, spotLights, shader, material, modelMatrix, mesh, textureID10);

        joint = new Model(gl, camera, light, spotLights,shader, material, modelMatrix, mesh, textureID15);

        mesh = new Mesh(gl, Cube.vertices.clone(), Cube.indices.clone());
        shader = new Shader(gl, "vs_cube.txt", "fs_cube.txt");
        material = new Material(new Vec3(1.0f, 0.5f, 0.31f), new Vec3(1.0f, 0.5f, 0.31f), new Vec3(0.5f, 0.5f, 0.5f), 32.0f);
        modelMatrix = Mat4Transform.translate(0,0.5f,0);
        head = new Model(gl, camera, light, spotLights,shader, material, modelMatrix, mesh, textureID15);

        tail = new Model(gl, camera, light, spotLights,shader, material, modelMatrix, mesh, textureID15);

        ear = new Model(gl, camera, light, spotLights,shader, material, modelMatrix, mesh, textureID15);

        foot = new Model(gl, camera, light, spotLights,shader, material, modelMatrix, mesh, textureID15);

        lampLight = new Model(gl, camera, light, spotLights,shader, material, modelMatrix, mesh);


        // lamp
        float armUpperHeight = 2f;
        float armUpperScale = 0.4f;
        float armLowerHeight = 1.7f;
        float armLowerScale = 0.38f;
        float jointScale = 0.4f;
        float ballsScale = 0.4f;
        float headHeight = 0.8f;
        float headWidth = 0.8f;
        float headLength = 0.8f;
        float tailHeight = 0.1f;
        float tailWidth = 0.1f;
        float tailLength = 1.6f;
        float earHeight = 0.4f;
        float earWidth = 0.05f;
        float earLength = 0.55f;
        float footHeight = 0.1f;
        float footWidth = 0.8f;
        float footLength = 0.8f;
        float lightSize = 0.2f;
        float right= 4f;

        lampRootRight = new NameNode("lampRight root");
        lampMoveTranslate = new TransformNode("lampRight transform",Mat4Transform.translate(xPosition,0,0));

        TransformNode lampTranslate = new TransformNode("lampRight transform",Mat4Transform.translate(0,footHeight,0));

        NameNode lampFoot = new NameNode("foot");
        TransformNode footTranslate = new TransformNode("lower arm translate", Mat4Transform.translate(right,0,0));
        Mat4 m = Mat4Transform.scale(footLength,footHeight,footWidth);
        m = Mat4.multiply(m, Mat4Transform.translate(0,0.5f,0));
        TransformNode footTransform = new TransformNode("foot transform", m);
        ModelNode footShape = new ModelNode("foot(foot)", foot);

        NameNode armLower = new NameNode("arm lower");
        TransformNode armLowerTranslate = new TransformNode("lower arm translate", Mat4Transform.translate(right,footHeight,0));
        armLowerRotate = new TransformNode("lower arm rotate", Mat4Transform.rotateAroundZ(0));
        m = new Mat4(1);
        //m = Mat4.multiply(m, Mat4Transform.rotateAroundZ(lowerInitial));
        m = Mat4.multiply(m, Mat4Transform.scale(armLowerScale,armLowerHeight,armLowerScale));
        m = Mat4.multiply(m, Mat4Transform.translate(0,0.5f,0));
        TransformNode lowerArmScale = new TransformNode("arm lower transform", m);
        ModelNode armLowerShape = new ModelNode("arm(lower)", arm);

        NameNode armUpper = new NameNode("arm upper");
        TransformNode armUpperTranslate = new TransformNode("upper arm translate", Mat4Transform.translate(0,footHeight + armLowerHeight + jointScale - 0.1f,0));
        armUpperRotate = new TransformNode("upper arm rotate", Mat4Transform.rotateAroundX(0));
        m = new Mat4(1);
        //m = Mat4.multiply(m, Mat4Transform.rotateAroundZ(upperInitial));
        m = Mat4.multiply(m, Mat4Transform.scale(armUpperScale,armUpperHeight,armUpperScale));
        m = Mat4.multiply(m, Mat4Transform.translate(0,0.5f,0));
        TransformNode upperArmScale = new TransformNode("arm lower transform", m);
        ModelNode armUpperShape = new ModelNode("arm(upper)", arm);

        NameNode armJoint = new NameNode("joint");
        m = new Mat4(1);
        m = Mat4.multiply(m, Mat4Transform.translate(0,footHeight + armLowerHeight-0.1f,0));
        m = Mat4.multiply(m, Mat4Transform.scale(jointScale,jointScale,jointScale));
        m = Mat4.multiply(m, Mat4Transform.translate(0,0.5f,0));
        TransformNode armJointTransform = new TransformNode("joint transform", m);
        ModelNode armJointShape = new ModelNode("joint(joint)", joint);

        NameNode jointTail = new NameNode("tail");
        TransformNode tailTranslate = new TransformNode("joint translate", Mat4Transform.translate(jointScale + (jointScale * 0.5f),footHeight+armLowerHeight-0.2f,0));
        m = new Mat4(1);
        m = Mat4.multiply(m, (Mat4Transform.rotateAroundZ(-30)));
        m = Mat4.multiply(m, Mat4Transform.scale(tailLength, tailHeight, tailWidth));
        m = Mat4.multiply(m, Mat4Transform.translate(0,0.5f,0));
        TransformNode jointTailScale = new TransformNode("joint tail transform", m);
        ModelNode jointTailShape = new ModelNode("joint(tail)", tail);

        NameNode headMain = new NameNode("headMain");
        TransformNode headTranslate = new TransformNode("head main translate", Mat4Transform.translate(0,armUpperHeight-0.2f,0));
        headRotate = new TransformNode("head rotate", Mat4Transform.rotateAroundX(0));
        m = new Mat4(1);
        //m = Mat4.multiply(m, Mat4Transform.rotateAroundZ(headInitial));
        m = Mat4.multiply(m, Mat4Transform.scale(headLength,headHeight,headWidth));
        m = Mat4.multiply(m, Mat4Transform.translate(0,0.5f,0));
        TransformNode headMainScale = new TransformNode("head main transform", m);
        ModelNode headMainShape = new ModelNode("head(main)", head);

        NameNode ear1 = new NameNode("ear1");
        TransformNode ear1Translate = new TransformNode("ear1 translate", Mat4Transform.translate((0.1f * headLength),headHeight,-0.5f*(headWidth - earWidth)-0.04f));
        m = new Mat4(1);
        m = Mat4.multiply(m, Mat4.multiply(Mat4Transform.rotateAroundX(-25),Mat4Transform.rotateAroundX(-135)));
        m = Mat4.multiply(m, Mat4Transform.scale(earLength,earHeight,earWidth));
        m = Mat4.multiply(m, Mat4Transform.translate(0,0.5f,0));
        TransformNode headEar1Scale = new TransformNode("ear1 transform", m);
        ModelNode headEar1Shape = new ModelNode("head(ear1)", ear);

        NameNode ear2 = new NameNode("ear2");
        TransformNode ear2Translate = new TransformNode("ear2 translate", Mat4Transform.translate((0.1f * headLength),headHeight,0.5f*(headWidth - earWidth)+0.04f));
        m = new Mat4(1);
        m = Mat4.multiply(m, Mat4.multiply(Mat4Transform.rotateAroundX(25),Mat4Transform.rotateAroundX(135)));
        m = Mat4.multiply(m, Mat4Transform.scale(earLength,earHeight,earWidth));
        m = Mat4.multiply(m, Mat4Transform.translate(0,0.5f,0));
        TransformNode headEar2Scale = new TransformNode("ear2 transform", m);
        ModelNode headEar2Shape = new ModelNode("head(ear2)", ear);

        NameNode headBall1 = new NameNode("ball1");
        m = new Mat4(1);
        m = Mat4.multiply(m, Mat4Transform.translate((ballsScale-headLength+0.2f),headHeight,-0.5f*(headWidth - ballsScale)));
        m = Mat4.multiply(m, Mat4Transform.rotateAroundY(90));
        m = Mat4.multiply(m, Mat4Transform.scale(ballsScale,ballsScale,ballsScale));
        m = Mat4.multiply(m, Mat4Transform.translate(0,0.5f,0));
        TransformNode headBall1Transform = new TransformNode("head1 transform", m);
        ModelNode headBall1Shape = new ModelNode("head(ball1)", ball);

        NameNode headBall2 = new NameNode("ball2");
        m = new Mat4(1);
        m = Mat4.multiply(m, Mat4Transform.translate((ballsScale-headLength+0.2f),headHeight,-0.5f*(-headWidth + ballsScale)));
        m = Mat4.multiply(m, Mat4Transform.rotateAroundY(90));
        m = Mat4.multiply(m, Mat4Transform.scale(ballsScale,ballsScale,ballsScale));
        m = Mat4.multiply(m, Mat4Transform.translate(0,0.5f,0));
        TransformNode headBall2Transform = new TransformNode("head2 transform", m);
        ModelNode headBall2Shape = new ModelNode("head(ball2)", ball);

        NameNode lightRight = new NameNode("light right lamp");
        m = new Mat4(1);
        m = Mat4.multiply(m, Mat4Transform.translate((lightSize*2)-headLength,(headHeight*0.5f)-(lightSize*0.5f),0));
        m = Mat4.multiply(m, Mat4Transform.scale(ballsScale,ballsScale,ballsScale));
        m = Mat4.multiply(m, Mat4Transform.translate(0,0.5f,0));
        TransformNode lightRightTransform = new TransformNode("right light transform", m);
        lampLightNode lightRightShape = new lampLightNode("lightRight(Right light)", lightRightLamp);

        lampRootRight.addChild(lampMoveTranslate);
            lampMoveTranslate.addChild(lampTranslate);
                lampTranslate.addChild(lampFoot);
                    lampFoot.addChild(footTranslate);
                        footTranslate.addChild(footTransform);
                        footTransform.addChild(footShape);
                    lampFoot.addChild(armLower);
                        armLower.addChild(armLowerTranslate);
                        armLowerTranslate.addChild(armLowerRotate);
                        armLowerRotate.addChild(lowerArmScale);
                        lowerArmScale.addChild(armLowerShape);
                            armLowerRotate.addChild(armJoint);
                                armJoint.addChild(armJointTransform);
                                armJointTransform.addChild(armJointShape);
                                armLowerRotate.addChild(jointTail);
                                    jointTail.addChild(tailTranslate);
                                    tailTranslate.addChild(jointTailScale);
                                    jointTailScale.addChild(jointTailShape);
                                armJoint.addChild(armUpper);
                                    armUpper.addChild(armUpperTranslate);
                                    armUpperTranslate.addChild(armUpperRotate);
                                    armUpperRotate.addChild(upperArmScale);
                                    upperArmScale.addChild(armUpperShape);
                                    armUpperRotate.addChild(headMain);
                                        headMain.addChild(headTranslate);
                                        headTranslate.addChild(headRotate);
                                        headRotate.addChild(headMainScale);
                                        headMainScale.addChild(headMainShape);
                                        headRotate.addChild(ear1);
                                            ear1.addChild(ear1Translate);
                                            ear1Translate.addChild(headEar1Scale);
                                            headEar1Scale.addChild(headEar1Shape);
                                        headRotate.addChild(ear2);
                                            ear2.addChild(ear2Translate);
                                            ear2Translate.addChild(headEar2Scale);
                                            headEar2Scale.addChild(headEar2Shape);
                                        headRotate.addChild(headBall1);
                                            headBall1.addChild(headBall1Transform);
                                            headBall1Transform.addChild(headBall1Shape);
                                        headRotate.addChild(headBall2);
                                            headBall2.addChild(headBall2Transform);
                                            headBall2Transform.addChild(headBall2Shape);
                                        headRotate.addChild(lightRight);
                                            lightRight.addChild(lightRightTransform);
                                            lightRightTransform.addChild(lightRightShape);

        lampFoot.update();
    }

    public void render(GL3 gl) {
        lampRootRight.draw(gl);
        lampRootRight.update();
        lightRightLamp.setPosition(-5,-5,-5);

    }

    private float lowerY1Right = 100f;
    private float lowerZ1Right = 80;
    private float upperZ1Right = -55f;
    private float headZ1Right = -50f;

    private float lowerY2Right = -110f;
    private float lowerZ2Right = -25f;
    private float upperZ2Right = 70f;
    private float headZ2Right = -10f;

    private float lowerY3Right = 0f;
    private float lowerZ3Right = 60f;
    private float upperZ3Right = -75f;
    private float headZ3Right = -35f;

    private float lyRight = 0;
    private float lzRight = 0;
    private float uzRight = 0;
    private float hzRight = 0;

    public void setPose1Right() {
        lyRight = lowerY1Right;
        lzRight = lowerZ1Right;
        uzRight = upperZ1Right;
        hzRight = headZ1Right;
    }

    public void setPose2Right() {
        lyRight = lowerY2Right;
        lzRight = lowerZ2Right;
        uzRight = upperZ2Right;
        hzRight = headZ2Right;
    }

    public void setPose3Right() {
        lyRight = lowerY3Right;
        lzRight = lowerZ3Right;
        uzRight = upperZ3Right;
        hzRight = headZ3Right;
    }


    public void firstPoseR(double elapsedTime) {

        float moveLy = ((lowerY1Right - lyRight) * (float) (Math.sin(elapsedTime)));
        float moveLz = ((lowerZ1Right - lzRight) * (float) (Math.sin(elapsedTime)));
        float moveUz = ((upperZ1Right - uzRight) * (float) (Math.sin(elapsedTime)));
        float moveHz = ((headZ1Right - hzRight) * (float) (Math.sin(elapsedTime)));

        Mat4 ly1 = Mat4.multiply(Mat4Transform.rotateAroundY(moveLy), Mat4Transform.rotateAroundY(lyRight));
        Mat4 lz1 = Mat4.multiply(Mat4Transform.rotateAroundZ(moveLz), Mat4Transform.rotateAroundZ(lzRight));

        armLowerRotate.setTransform(Mat4.multiply(ly1, lz1));
        armUpperRotate.setTransform(Mat4.multiply(Mat4Transform.rotateAroundZ(moveUz),
                Mat4Transform.rotateAroundZ(uzRight)));
        headRotate.setTransform(Mat4.multiply(Mat4Transform.rotateAroundZ(moveHz),
                Mat4Transform.rotateAroundZ(hzRight)));
    }

    public void secondPoseR(double elapsedTime) {
        float moveLy = ((lowerY2Right - lyRight) * (float)(Math.sin(elapsedTime)));
        float moveLz = ((lowerZ2Right - lzRight) * (float)(Math.sin(elapsedTime)));
        float moveUz = ((upperZ2Right - uzRight) * (float)(Math.sin(elapsedTime)));
        float moveHz = ((headZ2Right - hzRight) * (float)(Math.sin(elapsedTime)));

        Mat4 ly2 = Mat4.multiply(Mat4Transform.rotateAroundY(moveLy), Mat4Transform.rotateAroundY(lyRight));
        Mat4 lz2 = Mat4.multiply(Mat4Transform.rotateAroundZ(moveLz), Mat4Transform.rotateAroundZ(lzRight));

        armLowerRotate.setTransform(Mat4.multiply(ly2, lz2));
        armUpperRotate.setTransform(Mat4.multiply(Mat4Transform.rotateAroundZ(moveUz),
                Mat4Transform.rotateAroundZ(uzRight)));
        headRotate.setTransform(Mat4.multiply(Mat4Transform.rotateAroundZ(moveHz),
                Mat4Transform.rotateAroundZ(hzRight)));
    }

    public void thirdPoseR(double elapsedTime) {
        float moveLy = ((lowerY3Right - lyRight) * (float)(Math.sin(elapsedTime)));
        float moveLz = ((lowerZ3Right - lzRight) * (float)(Math.sin(elapsedTime)));
        float moveUz = ((upperZ3Right - uzRight) * (float)(Math.sin(elapsedTime)));
        float moveHz = ((headZ3Right - hzRight) * (float)(Math.sin(elapsedTime)));

        Mat4 ly3 = Mat4.multiply(Mat4Transform.rotateAroundY(moveLy), Mat4Transform.rotateAroundY(lyRight));
        Mat4 lz3 = Mat4.multiply(Mat4Transform.rotateAroundZ(moveLz), Mat4Transform.rotateAroundZ(lzRight));

        armLowerRotate.setTransform(Mat4.multiply(ly3, lz3));
        armUpperRotate.setTransform(Mat4.multiply(Mat4Transform.rotateAroundZ(moveUz),
                Mat4Transform.rotateAroundZ(uzRight)));
        headRotate.setTransform(Mat4.multiply(Mat4Transform.rotateAroundZ(moveHz),
                Mat4Transform.rotateAroundZ(hzRight)));
    }

    public void dispose(GL3 gl) {
        arm.dispose(gl);
        ball.dispose(gl);
        joint.dispose(gl);
        head.dispose(gl);
        tail.dispose(gl);
        ear.dispose(gl);
        foot.dispose(gl);
    }
}
