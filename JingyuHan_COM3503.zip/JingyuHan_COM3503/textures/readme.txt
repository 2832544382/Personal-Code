The following textures are from http://libnoise.sourceforge.net/examples/textures/index.html
jade.jpg
� 2003-2005 Jason Bevins, GNU General Public License.

https://github.com/nasa/NASA-3D-Resources
"All of these resources are free to download and use."
ear0xuu2.jpg
jup0vss1.jpg
mar0kuu2.jpg
ven0aaa2.jpg

